//#include <GL/glew.h>
#include "MyGLWidget.h"
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include <QTimer>
#include "MyForm.h"

#include <iostream>

// Constructor de la clase MyGLWidget
MyGLWidget::MyGLWidget (QWidget* parent) : QOpenGLWidget(parent), program(NULL)
{
  setFocusPolicy(Qt::StrongFocus);  // Establece la política de enfoque para recibir eventos de teclado
}

// Destructor de la clase MyGLWidget
MyGLWidget::~MyGLWidget ()
{
  if (program != NULL)
    delete program;
}

// Método que actualiza el tiempo y refresca la interfaz gráfica
void MyGLWidget::tick(){
    t+=MyForm::CLOCK_PERIOD_MILIS/1000.0f;
    emit timeUpdate(t);
    update(); // Actualiza la interfaz gráfica (repinta)
}

// Método que reinicia el tiempo a cero
void MyGLWidget::resetTime(){
    t=0;
    emit timeUpdate(t);
}

// Método que devuelve el tiempo actual
float MyGLWidget::getTime(){
    return t;
}

// Método que inicializa OpenGL
void MyGLWidget::initializeGL ()
{
  // Inicializa las funciones de OpenGL
  initializeOpenGLFunctions();
  
  glClearColor (200/255.0, 220/255.0, 255/255.0, 1.0); // Define el color de fondo
  carregaShaders();
  creaBuffers();

  // Inicialización de variables de estado
 }

// Método para renderizar la escena
void MyGLWidget::paintGL ()
{
// Código específico para pantallas Retina en Mac
#ifdef __APPLE__
  GLint vp[4];
  glGetIntegerv (GL_VIEWPORT, vp);
  ample = vp[2];
  alt = vp[3];
#endif

    glClear (GL_COLOR_BUFFER_BIT);  // Borra el frame-buffer
    program->bind();

    pintaTerra();

    float angle1, angle2;
    angle1 = 0.0;
    angle2 = 0.0;


    if(esModeManual()) {
        // Control manual de las bolas con el teclado
    } else {
        // Modo automático basado en el tiempo
    }
    float offsetX = radio;

    pintaBola(offsetX, 0);
    pintaSuport(offsetX, 0);

    pintaBola(-offsetX, 0);
    pintaSuport(-offsetX, 0);

    pintaBola(-3*offsetX, rotation2);       //primera bola
    pintaSuport(-3*offsetX, rotation2); 
    
    pintaBola(3*offsetX, rotation1);         //ultima bola
    pintaSuport(3*offsetX, rotation1);

    // Desactiva el VAO activo
    glBindVertexArray(0);
}

// Método que ajusta el tamaño de la ventana
void MyGLWidget::resizeGL (int w, int h)
{
  ample = w;
  alt = h;
}

// Métodos para pintar los diferentes objetos en la escena
void MyGLWidget::pintaBola(float d, float angle){
    transformacioBola(d,angle);
    glBindVertexArray(VAO_BOLA);
    glDrawArrays(GL_TRIANGLE_FAN, 0, CIRCLE_SAMPLES+1);
    pintaEstrella();
}

void MyGLWidget::pintaEstrella(){
    glBindVertexArray(VAO_ESTRELLA);
    //glDrawArrays(GL_TRIANGLE_FAN, 0, 10);
    glDrawElements(GL_TRIANGLES, 8*3, GL_UNSIGNED_INT, 0);

}

void MyGLWidget::pintaSuport(float d, float angle){
    transformacioSuport(d,angle);
    glBindVertexArray(VAO_SUPORT);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
}

void MyGLWidget::pintaTerra(){
    transformacioTerra();
    glBindVertexArray(VAO_TERRA);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 6);
}

// Método que maneja eventos de teclado
void MyGLWidget::keyPressEvent(QKeyEvent* event)
{
   /* makeCurrent();
    switch (event->key()) {
        case Qt::Key_A: {
            rotation1 += 5;
            std::cout << "Key " << rotation1 << std::endl;
            break;
        }
        case Qt::Key_D: {
            rotation1 -= 5;
            std::cout << "Key " << rotation1 << std::endl;
            break;
        }
        default: event->ignore(); break;
    }
    update(); */
}

// Métodos de transformación de los objetos
void MyGLWidget::transformacioTerra(){
    glm::mat4 transform (1.0f);
    glUniformMatrix4fv(transLoc, 1, GL_FALSE, &transform[0][0]);
}

void MyGLWidget::transformacioBola(float d, float angle){
    glm::mat4 transform (1.0f);
    

    //VOLTA PARA ONDE ONDE INICIOU
    transform = glm::translate(transform, glm::vec3(d, Terra_y,  0.0));

    //GIRA
    transform = glm::rotate(transform, glm::radians(angle), glm::vec3(0.0, 0.0, 1.0));

    //0,0
    transform = glm::translate(transform, glm::vec3(0, -Terra_y-radio, 0.0f));


    glUniformMatrix4fv(transLoc, 1, GL_FALSE, &transform[0][0]);
}

void MyGLWidget::transformacioSuport(float d, float angle){
    glm::mat4 transform (1.0f);

    //VOLTA PARA ONDE ONDE INICIOU
    transform = glm::translate(transform, glm::vec3(d, Terra_y,  0.0));

    //GIRA
    transform = glm::rotate(transform, glm::radians(angle), glm::vec3(0.0, 0.0, 1.0));

    //0,0
    transform = glm::translate(transform, glm::vec3(0, -Terra_y, 0.0f));


    glUniformMatrix4fv(transLoc, 1, GL_FALSE, &transform[0][0]);
}

// Métodos para crear buffers
void MyGLWidget::creaBuffers (){
    creaBufferBola();
    creaBufferSuport();
    creaBufferTerra();
    creaBufferEstrella();
    glBindVertexArray(0);   //Desactiva el VAO
}

// Método para crear los VBOs (Vertex Buffer Objects)
void MyGLWidget::createVBOs(int size,  glm::vec3 Colors[], glm::vec3 Vertices[] ){
    GLuint VBO[2];   

    //Crea el buffer de vertices
    glGenBuffers(2, VBO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO[0]);
    glBufferData(GL_ARRAY_BUFFER, size, Vertices, GL_STATIC_DRAW);
    glVertexAttribPointer(vertexLoc, 3, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(vertexLoc);

    //Crea el buffer de colores
    glBindBuffer(GL_ARRAY_BUFFER, VBO[1]);
    glBufferData(GL_ARRAY_BUFFER, size, Colors, GL_STATIC_DRAW);
    glVertexAttribPointer(colorLoc, 3, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(colorLoc);

    //Desactiva el VAO
    glBindVertexArray(0);
}

// Métodos para crear buffers específicos para cada objeto
void MyGLWidget::creaBufferTerra(){

    glm::vec3 Vertices[6]; 
    Vertices[0] = glm::vec3(-1.00,  0.75, 0.0);
    Vertices[1] = glm::vec3(-0.50,  Terra_y, 0.0);
    Vertices[2] = glm::vec3(-1.00,  1.0, 0.0);
    Vertices[3] = glm::vec3( 0.5,  Terra_y, 0.0);
    Vertices[4] = glm::vec3( 1.00,  1.0, 0.0);
    Vertices[5] = glm::vec3( 1.00,  0.75, 0.0);

    // Crea el VAO usado para pintar
    glGenVertexArrays(1, &VAO_TERRA);
    glBindVertexArray(VAO_TERRA);

    glm::vec3 Colors[6];
    for(int i=0;i<6;i++) {
        Colors[i] = COLOR_MARRO;
    }

    createVBOs( sizeof(Vertices), Colors, Vertices );
}

void MyGLWidget::creaBufferSuport(){
    glm::vec3 Vertices[4];  

    Vertices[0] = glm::vec3(+Suport_x,  Suport_y,  0.0);
    Vertices[1] = glm::vec3(-Suport_x,  Suport_y,  0.0);
    Vertices[2] = glm::vec3(+Suport_x,  +Terra_y,  0.0);
    Vertices[3] = glm::vec3(-Suport_x,  +Terra_y,  0.0);

    glm::vec3 Colors[4];
    for(int i=0;i<4;i++) {
        Colors[i] = COLOR_BLAU;
    }

    // Crea el VAO usado para pintar
    glGenVertexArrays(1, &VAO_SUPORT);
    glBindVertexArray(VAO_SUPORT);

    createVBOs( sizeof(Vertices), Colors, Vertices );
}

void MyGLWidget::creaBufferBola(){
    glm::vec3   Colors[CIRCLE_SAMPLES+1];
    glm::vec3 Vertices[CIRCLE_SAMPLES+1];
    Vertices[0] = glm::vec3(0.0f , 0.0f, 0.0f);
    Colors[0]   = glm::vec3( 1.0,1.0,1.0);

    QColor q(244,247, 17);
    float h,s,v,a;
    q.getHsvF(&h,&s,&v,&a); // Trabajemos con coordenadas de HSV (???) de corlores

    //float radi      = 0.5;
    float alfa      = 0;
    float deltaAlfa = 2.0*M_PI / (CIRCLE_SAMPLES-1);
    float deltaV    = 1.0 / (CIRCLE_SAMPLES-1);

    for(int k=1;k<=CIRCLE_SAMPLES; k++, alfa+=deltaAlfa){
        // calculo de las coordenadas de los vertex
        Vertices[k] = glm::vec3( radio * cos(alfa), radio * sin(alfa), 0.0);
        // calculo del color del gradiante
        q.setHsvF(h,s,v,a);
        Colors[k] = glm::vec3(q.red()/255.0, q.green()/255.0, q.blue()/255.0);
        if(k<CIRCLE_SAMPLES/2) {v-=deltaV;} else {v+=deltaV;}
    }

    // Crea el VAO usado para pintar

    glGenVertexArrays(1, &VAO_BOLA);
    glBindVertexArray(VAO_BOLA);

    createVBOs(sizeof(Vertices),  Colors, Vertices );
}

void MyGLWidget::creaBufferEstrella()
{
    const int sizee = 10;
    glm::vec3 Vertices[sizee];


    float angulo_inicial = M_PI / 2.0f; // Começar no topo
    float raio_externo = radio * 0.25f; // Picos da estrela
    float raio_interno = radio * 0.125f; // Valas da estrela

    for (int i = 0; i < sizee; i++) {
        float angulo = angulo_inicial + i * (M_PI / 5.0f); // 10 vértices, espaçados a cada 36°
        float raio = (i % 2 == 0) ? raio_externo : raio_interno; // Alternar entre pico e vale
        Vertices[i] = glm::vec3(raio * cos(angulo), raio * sin(angulo), 0.0f);
        
        // Imprimir no terminal
        std::cout << "Vertices[" << i << "] = (" 
        << Vertices[i].x * 100 << ", " 
        << Vertices[i].y * 100 << ", " 
        << Vertices[i].z * 100 << ")" << std::endl;
    }

    glm::vec3 Colors[sizee];
    for (int i = 0; i < sizee; i++){
        Colors[i] = glm::vec3(236.0f / 255.0f, 107.0f / 255.0f, 70.0f / 255.0f);
    }

    GLuint Indices[] = {
        9, 0, 1,
        1, 2, 3,
        3, 4, 5,
        5, 6, 7,
        7, 8, 9,
        //DENTRO DEL TRIANGULO
        1, 5, 3,
        1, 7, 9,
        1, 5, 7
    };


     // Crea el VAO usado para pintar
     glGenVertexArrays(1, &VAO_ESTRELLA);
     glBindVertexArray(VAO_ESTRELLA);
     
     GLuint EBO;
     glGenBuffers(1, &EBO);
     glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
     glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(Indices), Indices, GL_STATIC_DRAW);


      createVBOs( sizeof(Vertices), Colors, Vertices);
    // Crear VAO_ESTRELLA
    // Crear el búfer de vértices y colores
    // Luego, será necesario programar y llamar
    // adecuadamente al método pintaEstrella()
}


void MyGLWidget::carregaShaders()
{
  // Creamos los shaders para el fragment shader y el vertex shader
  QOpenGLShader fs (QOpenGLShader::Fragment, this);
  QOpenGLShader vs (QOpenGLShader::Vertex, this);
  // Cargamos el código de los archivos y los compilamos
  fs.compileSourceFile("shaders/basicShader.frag");
  vs.compileSourceFile("shaders/basicShader.vert");
  // Creamos el programa
  program = new QOpenGLShaderProgram(this);
  // Le añadimos los shaders correspondientes
  program->addShader(&fs);
  program->addShader(&vs);
  // Enlazamos el programa
  program->link();
  // Indicamos que este es el programa que queremos usar
  program->bind();

  // Obtenemos el identificador para el atributo “vertex” del vertex shader
  vertexLoc = glGetAttribLocation (program->programId(), "vertex");
  colorLoc = glGetAttribLocation (program->programId(), "color");
  transLoc = glGetUniformLocation(program->programId(), "TG");
}